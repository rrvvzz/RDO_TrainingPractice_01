﻿using System;

namespace RDO_Task_03
{
    class Program
    {
        static void Main(string[] args)     
        {
            String password = "qwerty";
            int popitka = 1;
            do
            {
                    Console.Write("Введите пароль - ");
                    Console.Write("Попытка - ");
                    Console.WriteLine(popitka);
                    popitka++;
                    password = Convert.ToString(Console.ReadLine());
                    if (password == "qwerty")
                    {
                        Console.Write("Вы ввели верный пароль!");
                        break;
                    }    
            } while (popitka <= 3);
        }
    }
}
