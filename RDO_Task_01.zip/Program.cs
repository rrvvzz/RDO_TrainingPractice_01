﻿using System;

namespace RDO_Task_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int buykrystall = 0;
            int balancekrystall = 0;
            int kurskrystall;
            string prodolzhenie;

            //Задается баланс кошелька
            Console.Write("Введите количество золота в кошельке -  ");
            int balancegold = Convert.ToInt32(Console.ReadLine());

            //Вывод данных о балансе перед сделкой
            Console.Write("Остаток золота = ");
            Console.WriteLine(balancegold);
            Console.Write("Остаток кристаллов = ");
            Console.WriteLine(balancekrystall);

            //Задается курс кристаллов
            Console.Write("Задайте курс кристаллов (1 кристалл = заданному количеству золота) =  ");
            kurskrystall = Convert.ToInt32(Console.ReadLine());

            konvert:

            //Реплика продавца
            Console.Write("Введите количество кристаллов, которое вы хотите купить -  ");
            buykrystall = Convert.ToInt32(Console.ReadLine());


            //Условие, если операция возможна
            if (balancegold >= buykrystall * kurskrystall)
            {
                balancegold = balancegold - buykrystall * kurskrystall;
                balancekrystall = balancekrystall + buykrystall;
                Console.Write("Остаток золота = ");
                Console.WriteLine(balancegold);
                Console.Write("Остаток кристаллов = ");
                Console.WriteLine(balancekrystall);
            }

            //Вывод первоначального баланса в случае, когда операция невозможна
            else
            {
                Console.WriteLine("Операция невозможна, текущий баланс: ");
                Console.Write("Остаток золота = ");
                Console.WriteLine(balancegold);
                Console.Write("Остаток кристаллов = ");
                Console.WriteLine(balancekrystall);
            }

            yesorno:

            //Условие о возможности выполнения следующей конвертации
            Console.Write("Желаете поменяться еще? (ДА или НЕТ)  ");
            prodolzhenie = Convert.ToString(Console.ReadLine());

            //Возврат на повторную конвертацию золота в кристаллы
            if (prodolzhenie == "Да" || prodolzhenie == "да" || prodolzhenie == "ДА")
                goto konvert;
            
            //Вывод конечного баланса
            if (prodolzhenie == "Нет" || prodolzhenie == "нет" || prodolzhenie == "НЕТ")
            {
                Console.WriteLine("Конечный баланс");
                Console.Write("Остаток золота = ");
                Console.WriteLine(balancegold);
                Console.Write("Остаток кристаллов = ");
                Console.WriteLine(balancekrystall);
            }

            //Реакция программы на ответ, который не заложен в условии
            else
            {
                Console.Write("Я вас не понимаю, повторите пожалуйста -  ");
                goto yesorno;
            }
        }
    }
}
