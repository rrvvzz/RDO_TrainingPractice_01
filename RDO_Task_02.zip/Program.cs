﻿using System;

namespace RDO_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {
            String slovo;
            int popitka = 0;
            do
            {
                popitka++; //Счетчик попыток
                Console.WriteLine("Угадайте слово для завершения работы программы ");
                Console.Write("Попытка - ");
                Console.WriteLine(popitka);
                slovo = Convert.ToString(Console.ReadLine());
            } while (slovo != "exit");

        }
    }
}
