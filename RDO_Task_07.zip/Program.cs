﻿using System;

namespace RDO_Task_07
{
    class Program
    {
        //Заполнение массива случайными числами
        static void RandomFill(int[] array)
        {
            Random random = new Random();

            for (int i = 0; i < array.Length; ++i)
            {
                array[i] = random.Next();
            }
        }

        //Вывод массива
        static void Print(int[] array)
        {
            for (int i = 0; i < array.Length; ++i)
            {
                Console.WriteLine(i + " : " + array[i]);
            }
        }

        //Перемешивание массива
        static int[] Shuffle(int[] array)
        {
            Random random = new Random();
            int temporaryElement, randomPosition;

            //Идём в цикле по массиву от его конца до начала
            for (int i = array.Length - 1; i > 0; i--)
            {
                randomPosition = random.Next(i);
                temporaryElement = array[i];
                array[i] = array[randomPosition];
                array[randomPosition] = temporaryElement;
            }

            //Возвращаем перемешанный массив
            return array;
        }

        //Главная функция программы
        static void Main(string[] args)
        {
            //Ввод размерности массива
            Console.Write("Введите размерность массива - ");
            uint arraySize = Convert.ToUInt32(Console.ReadLine());

            //Заполняем массив случайными числами
            int[] array = new int[arraySize];
            RandomFill(array);

            //Вывод исходного массива
            Console.WriteLine("\nИсходный массив: ");
            Print(array);

            //Перемешивание элементов массива
            Shuffle(array);

            //Вывод перемешанного массива
            Console.WriteLine("\nПеремешанный массив: ");
            Print(array);

            Console.ReadKey();
        }
    }
}